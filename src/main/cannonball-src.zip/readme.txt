===========
Cannonball
===========
Cannonball made by Chris White and the Cannonball Team
Ported to GCW0 by Gameblabla

This is the first release of the GCW0 port, there will probably be another one.
Since i don't actually own a GCW0, i have no idea how fast or slow it is !

(I worked on the gcw0 port using qemu)

==============
INSTALLATION
==============

Put the extracted OutRun roms here :
/media/home/roms

You must extract the rom here if it is a zip !

Then install the opk like any GCW0 games.
(Put it in /media/data/apps/ or something like that)

===========
CONTROLS
===========

You can change the controls at any time if you don't like them and save them.
Here's the default mapping :

A : Accelerate
B : Brake
X : Money
Y : Gear
L : Menu
R : Change view
START : START
SELECT : Quit