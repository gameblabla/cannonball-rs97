mksquashfs ./opk canon.opk -all-root -noappend -no-exports -no-xattrs
